document.addEventListener("DOMContentLoaded", function () {
    const sidebar = document.getElementById("sidebar");
    const sidebar_logo = document.getElementById("logo--sidebar");
    const conteudo = document.getElementById("content");
    const toggleButton = document.querySelector(".toggle-button");
    const iframe = document.getElementById("mainIframe");

    toggleButton.addEventListener("click", function () {
         sidebar.classList.toggle("fechado");
         conteudo.classList.toggle("alterado");
    });

    sidebar_logo.addEventListener("click", function () {
         sidebar.classList.toggle("fechado");
         conteudo.classList.toggle("alterado");
    });

    document.querySelectorAll(".sidebar ul li").forEach(function (item) {
         item.addEventListener("click", function () {
              const src = item.getAttribute("data-src");
              iframe.src = src; // Atualiza o src do iframe com base no item clicado
         });
    });
});